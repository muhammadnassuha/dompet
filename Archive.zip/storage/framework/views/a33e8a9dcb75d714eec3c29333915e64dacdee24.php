
<?php $__env->startSection('content'); ?>
	<section class="mb-4">
	  	<div class="card">
	    	<div class="card-body d-flex justify-content-between">
	      		<h4 class="h4-responsive mt-3">User Management</h4>
	      	<div>
	        <a href="<?php echo e(route('user-setting.users.create')); ?>" title="Add New User" class="btn btn-primary modal-show"><i class="fa fa-plus"></i> Add User</a>
	  	</div>
	</section>

  	<section class="mb-5">
		<div class="card">
			<div class="card-body">
				<div class="table-">
					<table id="dtMaterialDesignExample" class="table table-hover table-condensed" cellspacing="0" width="100%">
        				<thead class="thead-dark">
					        <tr>
					          <th width="5%">No</th>
					          <th width="15%">Full Name</th>
					          <th width="15%">Email Address</th>
					          <th width="10%">Created At</th>
					          <!-- <th width="10%">Created By</th> -->
					          <th width="10%">Last Sign In</th>
					          <th width="10%">Action</th>
					        </tr>
					    </thead>
					</table>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function() {
	    $('#dtMaterialDesignExample').DataTable({
	    	responsive : true,
	    	processing : true,
	    	serverSide : true,
	    	ajax : "<?php echo e(route('table.user-management')); ?>",
	    	columns : [
	    		{data : 'id', name : 'id'},
	    		{data : 'name', name : 'name'},
	    		{data : 'email', name : 'email'},
	    		{data : 'created_at', name : 'created_at'},
	    		// {data : 'created_by', name : 'created_by'},
	    		{data : 'last_sign_in_at', name : 'last_sign_in_at'},
	    		{data : 'action', name : 'action'}

	    	]
	    });
	    
	    $('#dtMaterialDesignExample_wrapper, #dt-material-checkbox_wrapper').find('label').each(function () {
	      $(this).parent().append($(this).children());
	    });

    	$('#dtMaterialDesignExample_wrapper .dataTables_filter, #dt-material-checkbox_wrapper .dataTables_filter').find('input').each(function () {
      			$('input').attr("placeholder", "Search");
      			$('input').removeClass('form-control-sm');
    	});

    	$('#dtMaterialDesignExample_wrapper .dataTables_length, #dt-material-checkbox_wrapper .dataTables_length').addClass('d-flex flex-row');
    
    	$('#dtMaterialDesignExample_wrapper select, #dt-material-checkbox_wrapper select').removeClass('custom-select custom-select-sm form-control form-control-sm');

    	$('#dtMaterialDesignExample_wrapper select, #dt-material-checkbox_wrapper select').addClass('mdb-select');
    	$('#dtMaterialDesignExample_wrapper .mdb-select, #dt-material-checkbox_wrapper .mdb-select').materialSelect();
    	$('#dtMaterialDesignExample_wrapper .dataTables_filte, #dt-material-checkbox_wrapper .dataTables_filterr').find('label').remove();
		});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('base.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rian\engineering_fee\resources\views/master/user/index.blade.php ENDPATH**/ ?>