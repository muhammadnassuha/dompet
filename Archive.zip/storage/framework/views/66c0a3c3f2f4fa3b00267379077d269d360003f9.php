<!DOCTYPE html>
<html>
<?php echo $__env->make('base.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php echo $__env->make('base.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <aside class="main-sidebar">
      <section class="sidebar">
        <div class="user-panel">
          <div class="pull-left image">
            <img src="<?php echo e(asset('images/img-user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
          </div>
          <div class="pull-left info">
            <p>
              <?php echo e(Auth::user()->name); ?>

            </p>
            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
          </div>
        </div>
        <?php echo $__env->make('base.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </section>
    </aside>
    

    <div class="content-wrapper">
      <section class="content-header">
        <h1>
            <?php echo $__env->yieldContent('page_icon'); ?>
            <?php echo $__env->yieldContent('page_title'); ?>
            <small><?php echo $__env->yieldContent('page_subtitle'); ?></small>
        </h1>
        <?php echo $__env->yieldContent('breadcrumb'); ?>
      </section>

      <section class="content">
        <?php echo $__env->yieldContent('menu'); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('base.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </section>
    </div>

  <?php echo $__env->make('base.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</div>
<?php echo $__env->make('base.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /Users/intiartha/Documents/castercode/management_pro/resources/views/base/main.blade.php ENDPATH**/ ?>