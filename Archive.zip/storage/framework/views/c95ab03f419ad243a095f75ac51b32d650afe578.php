
<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered">
			<tbody>
				
				<tr>
					<th>Project Name</th>
					<td><?php echo e($model->project_name); ?></td>
				</tr>
				<tr>
					<th>Project Category</th>
					<td><?php echo e($model->category_name); ?></td>
				</tr>
				<tr>
					<th>Project Description</th>
					<td><?php echo e($model->project_description); ?></td>
				</tr>
				<tr>
					<th>Project Detail</th>
					<td><?php echo e($model->project_detail); ?></td>
				</tr>
				<tr>
					<th>Project Deadline</th>
					<?php if($days <= 7): ?>
					<td>
						<?php echo e(date('d/m/Y', strtotime($model->project_start))); ?> - <?php echo e(date('d/m/Y', strtotime($model->project_end))); ?> <i class="blink_me" style="color:red">(<?php echo e($days); ?> days left)</i>
					</td>
					<?php else: ?>
					<td>
						<?php echo e(date('d/m/Y', strtotime($model->project_start))); ?> - <?php echo e(date('d/m/Y', strtotime($model->project_end))); ?> <i>(<?php echo e($days); ?> days left)</i>
					</td>
					<?php endif; ?>
				</tr>
				
				<tr>
                    <th>Created by</th>
                    <td><?php echo e($uti->getUser($model->created_by)); ?></td>
                </tr>
                <tr>
                    <th>Created Date</th>
                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($model->created_at))); ?></td>
                </tr>
                <tr>
                    <th>Updated By</th>
                    <td><?php echo e($uti->getUser($model->updated_by)); ?></td>
                </tr>
                <tr>
                    <th>Updated Date</th>
                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($model->updated_at))); ?></td>
                </tr>
				
			</tbody>
		</table>
	</div>
	
</div>
<?php /**PATH /Users/intiartha/Documents/castercode/management_pro/resources/views/master/project/detail.blade.php ENDPATH**/ ?>