<?php
    $method = $model->exists ? 'PUT' : 'POST';
?>
<?php echo Form::model($model, [
    'route' => $model->exists ? ['role.role.update', $model->id] : 'role.role.store',
    'method'=> $method,
]); ?>


    <div class="form-group">
        <label for="code" class="control-label">Code</label>
        <?php echo Form::text('code', null, ['class'=>'form-control', 'id'=>'code', 'maxlength'=>5]); ?>

    </div>
    <div class="form-group">
        <label for="role" class="control-label">Role</label>
        <?php echo Form::text('role', null, ['class'=>'form-control', 'id'=>'role']); ?>

    </div>

    <div class="form-group">
        <label for="active" class="control-label">Active</label>
        <div>
            <?php echo Form::checkbox('active', null, null, ['id'=>'active']); ?> 
        </div>
    </div>

<?php echo Form::close(); ?><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/master/role/form.blade.php ENDPATH**/ ?>