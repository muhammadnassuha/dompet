<div id="slide-out" class="side-nav sn-bg-4 fixed">
  <ul class="custom-scrollbar">
    <!-- Logo -->
    <li class="logo-sn waves-effect py-3">
      <div class="text-center">
        <a href="#" class="pl-0"><img src="<?php echo e(asset('images/logo-mdb-transaprent-noshadows.png')); ?>"></a>
      </div>
    </li>
    <!-- Search Form -->
    
    <!-- Side navigation links -->
    <li>
      <ul class="collapsible collapsible-accordion">
        <li>
          <a href="/" class="collapsible-header waves-effect"><i class="w-fa fas fa-tachometer-alt"></i>Dashboard</a>
        </li>
        

        <li>
          <a class="collapsible-header waves-effect arrow-r" href="#">
            <i class="w-fa fas fa-cog"></i>Setting<i class="fas fa-angle-down rotate-icon"></i>
          </a>
          <div class="collapsible-body">
            <ul>
              <li>
                <a href="<?php echo e(route('user-setting.users.index')); ?>" class="waves-effect">User Management</a>
              </li>
              <li>
                <a href="#" class="waves-effect">Module</a>
              </li>
              <li>
                <a href="#" class="waves-effect">Role</a>
              </li>
              <li>
                <a href="#" class="waves-effect">Access Role</a>
              </li>
              
            </ul>
          </div>
        </li>

        
    <!-- Side navigation links -->
  </ul>
  <div class="sidenav-bg mask-strong"></div>
</div><?php /**PATH D:\Rian\engineering_fee\resources\views/base/menu.blade.php ENDPATH**/ ?>