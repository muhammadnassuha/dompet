<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered">
			<tbody>
				
				<tr>
					<th>Category Name</th>
					<td><?php echo e($model->category_name); ?></td>
				</tr>
				<tr>
					<th>Description</th>
					<td><?php echo e($model->description); ?></td>
				</tr>
				<tr>
                    <th>Created by</th>
                    <td><?php echo e($uti->getUser($model->created_by)); ?></td>
                </tr>
                <tr>
                    <th>Created Date</th>
                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($model->created_at))); ?></td>
                </tr>
                <tr>
                    <th>Updated By</th>
                    <td><?php echo e($uti->getUser($model->updated_by)); ?></td>
                </tr>
                <tr>
                    <th>Updated Date</th>
                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($model->updated_at))); ?></td>
                </tr>
				
			</tbody>
		</table>
	</div>
	
</div>
<?php /**PATH /Users/intiartha/Documents/castercode/management_pro/resources/views/master/category-project/detail.blade.php ENDPATH**/ ?>