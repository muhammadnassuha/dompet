<head>
  
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Dashboard Administrator</title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/css-bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/css-font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/css-ionicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/jvectormap-jquery-jvectormap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/css-AdminLTE.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/skins-_all-skins.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('select2/dist/css/select2.min.css')); ?>">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

<style type="text/css">
	.blink_me {
	  animation: blinker 1s linear infinite;
	}

	@keyframes  blinker {
	  50% {
	    opacity: 0;
	  }
	}
</style>

</head><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/base/head.blade.php ENDPATH**/ ?>