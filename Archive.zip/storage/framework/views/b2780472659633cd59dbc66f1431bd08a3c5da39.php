
<?php $__env->startSection('page_icon'); ?> <i class="fa fa-dashboard"> </i><?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?> Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> Home <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/master/dashboard/index.blade.php ENDPATH**/ ?>