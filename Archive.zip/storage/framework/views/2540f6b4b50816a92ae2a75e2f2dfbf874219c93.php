
<?php $__env->startSection('title'); ?> User <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_icon'); ?> <i class="fa fa-users"></i> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?> User <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> list <?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <div class="box box-solid" style="text-align:right;">
        <div class="box-body">
            <a href="<?php echo e(route('user.sys-user.create')); ?>" class="modal-show btn btn-success" title="Create Project">
                <i class="fa fa-plus"></i> Create
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-solid">
        <div class="box-header">
              <h3 class="box-title">Data Table With Full Features </h3>
            </div>
        <div class="box-body">
            <table id="datatable" class="table table-hover table-condensed">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Fullname</th>
                        <th>Email</th>
                        <th>Created By</th>
                        <th>Created Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>

        $('#datatable').DataTable({
            responsive : true,
            processing : true,
            serverSide : true,
            ajax: "<?php echo e(route('table.user')); ?>",
            columns: [
                {data : 'DT_RowIndex', name : 'id'},
                {data : 'name', name : 'name'},
                {data : 'email', name : 'email'},
                {data : 'created_by', name : 'created_by'},
                {data : 'created_at', name : 'created_at'},
                {data : 'action', name : 'action'}
            ]
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('base.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/intiartha/Documents/castercode/nutech/resources/views/master/user/index.blade.php ENDPATH**/ ?>