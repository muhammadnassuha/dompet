<?php
    $method = $model->exists ? 'PUT' : 'POST';
?>
<?php echo Form::model($model, [
    'route' => $model->exists ? ['user-setting.users.update', $model->id] : 'user-setting.users.store',
    'method'=> $method,
    'id' => 'form-validation'
]); ?>


<div class="card">
	<div class="card-body px-lg-5 pt-0">
		
			<div class="form-row ">
				<div class="col">
					<div class="md-form">
						<?php echo Form::text('first_name', null, ['class'=>'form-control', 'id'=>'first_name', 'required'=>'required']); ?>

						<label for="materialRegisterFormFirstName">First name *</label>
						<div class="invalid-feedback">
			                Please fill out this field first name
			            </div>
					</div>
				</div>
				<div class="col">
					<div class="md-form">
						<?php echo Form::text('last_name', null, ['class'=>'form-control', 'id'=>'last_name','required'=>'required']); ?>

						<label for="materialRegisterFormLastName">Last name *</label>

						<div class="invalid-feedback">
			                Please fill out this field last name
			            </div>
					</div>
				</div>
			</div>
			<!-- E-mail -->
			<div class="md-form mt-0">
				<textarea type="text" id="address" name="address" rows="2" class="form-control md-textarea"></textarea>
				<label for="materialRegisterFormEmail">Address</label>
				<!-- <small id="materialRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">Optional</small> -->
				
			</div>

			<div class="md-form mt-0">
				<?php echo Form::email('email', null, ['class'=>'form-control', 'id'=>'email', 'required'=>'required']); ?>

				<label for="materialRegisterFormEmail">Email Address *</label>

				<div class="invalid-feedback">
	                Please fill out this field email
	            </div>
			</div>
			<!-- Password -->
			<div class="md-form">
				<input type="password" id="password" required="required" name="password" class="form-control" aria-describedby="materialRegisterFormPasswordHelpBlock">
				<label for="materialRegisterFormPassword">Password *</label>
				<div class="invalid-feedback">
	                Please fill out this field password at least 8 characters
	            </div>
			</div>

			<div class="md-form">
				<input type="password" required="required" id="confirm_password" name="confirm_password" class="form-control" aria-describedby="materialRegisterFormPasswordHelpBlock">
				<label for="materialRegisterFormPassword">Confirm Password *</label>
				<div class="invalid-feedback">
	                Please fill out this field confirm password at least 8 characters
	            </div>
			</div>
			<!-- Phone number -->
			<div class="md-form">
				<input type="number" id="phone_number" name="phone_number" class="form-control" aria-describedby="materialRegisterFormPhoneHelpBlock">
				<label for="materialRegisterFormPhone">Phone number</label>
				<!-- <small id="materialRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">Optional</small> -->
			</div>

			<small id="materialRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4" style="color:#dc3545 !important;">(*) Indicates required field.</small>
		</div>
	</div>



<?php echo Form::close(); ?><?php /**PATH D:\Rian\engineering_fee\resources\views/master/user/create.blade.php ENDPATH**/ ?>