<?php
    $method = $model->exists ? 'PUT' : 'POST';
?>
<?php echo Form::model($model, [
    'route' => $model->exists ? ['category.category-project.update', $model->id] : 'category.category-project.store',
    'method'=> $method,
]); ?>


    <div class="form-group">
        <label for="category_name" class="control-label">Category Name*</label>
        <?php echo Form::text('category_name', null, ['class'=>'form-control', 'id'=>'category_name']); ?>

    </div>
    <div class="form-group">
        <label for="category_name" class="control-label">Description*</label>
        <?php echo Form::textarea('description', null, ['class'=>'form-control', 'id'=>'description']); ?>

    </div>

<?php echo Form::close(); ?>

<?php /**PATH /Users/intiartha/Documents/castercode/management_pro/resources/views/master/category-project/create.blade.php ENDPATH**/ ?>