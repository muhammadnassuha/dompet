

<?php
    $method = $model->exists ? 'PUT' : 'POST';
?>
<?php echo Form::model($model, [
    'route' => $model->exists ? ['produk.produk.update', $model->id] : 'produk.produk.store',
    'method'=> $method,
]); ?>

    
    <input type="hidden" name="doc_image" id="doc_image" value="<?php echo e($model->foto_barang); ?>">
    <input type="hidden" name="id" id="id" value="<?php echo e($model->id); ?>">
   
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="asset_name" class="control-label">Foto Barang*</label>
                <div class="dropzone" id="apake"></div>
                <input type="hidden" name="foto_barang" id="image"></input>
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <label for="nama_barang" class="control-label">Nama Barang*</label>
                <?php echo Form::text('nama_barang', null, ['class'=>'form-control', 'id'=>'nama_barang']); ?>

            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="harga_beli" class="control-label">Harga Beli*</label>
                <?php echo Form::text('harga_beli', $harga_beli, ['class'=>'form-control', 'id'=>'harga_beli']); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="harga_jual" class="control-label">Harga Jual*</label>
                <?php echo Form::text('harga_jual', $harga_jual, ['class'=>'form-control', 'id'=>'harga_jual']); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="stok" class="control-label">Stok Barang*</label>
                <?php echo Form::text('stok', null, ['class'=>'form-control', 'id'=>'stok']); ?>

            </div>
        </div>
    </div>

<?php echo Form::close(); ?>


<script type="text/javascript">
    var harga_beli = document.getElementById("harga_beli");
    var harga_jual = document.getElementById("harga_jual");

    harga_beli.addEventListener("keyup", function(e) {
      harga_beli.value = formatRupiah(this.value, "");
    });

    harga_jual.addEventListener("keyup", function(e) {
      harga_jual.value = formatRupiah(this.value, "");
    });


    function formatRupiah(angka, prefix) {
        var number_string = angka.replace(/[^\d]/g, "").toString(),
            split = number_string.split(","),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (ribuan) {
            separator = sisa ? "," : "";
            rupiah += separator + ribuan.join(",");
        }

        rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
        return prefix == undefined ? rupiah : rupiah ? "" + rupiah : "";
    }

    

    Dropzone.options.apake = false;
    var apake = new Dropzone('#apake', {
        url: '<?php echo e(route('produk.image')); ?>',
        params: { _token: $('meta[name="csrf-token"]').attr('content') },
        paramName: 'img',
        acceptedFiles: '.jpg, .png',
        maxFiles: 1,
        maxFilesize: 100,
        addRemoveLinks: true,
        parallelUploads: 2
    });

    if($('#doc_image').val() != ""){
        var id = document.getElementById("id").value;
        var _token = $('meta[name="csrf-token"]').attr('content');

        $.ajax({
              url: '<?php echo e(route('produk.show-image')); ?>',
              data: { id, _token },
              method: 'post',
              success: function(data) {
                var i = 1;


                $.each(data.imgs, function(key, value) {
                  var mockFile = { name: value.nama, size: value.size, imgNo: i, accepted: true };
                  apake.emit('addedfile', mockFile);
                  apake.createThumbnailFromUrl(mockFile, '../../../' + value.url);
                  apake.emit('complete', mockFile);
                  apake.files.push(mockFile);
                  i = i + 1;

                });

            }
        });
    }

    apake.on('success', function(file, data) {
        $('#image').val(data);
    });

    apake.on('removedfile', function(file) {
        $('#image').val('');
    });

    function setInputFilter(textbox, inputFilter) {
      ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
        textbox.addEventListener(event, function() {
          if (inputFilter(this.value)) {
            this.oldValue = this.value;
            this.oldSelectionStart = this.selectionStart;
            this.oldSelectionEnd = this.selectionEnd;
          } else if (this.hasOwnProperty("oldValue")) {
            this.value = this.oldValue;
            this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
          } else {
            this.value = "";
          }
        });
      });
    }

    setInputFilter(document.getElementById("stok"), function(value) {
      return /^-?\d*$/.test(value); });


    
</script>
<?php /**PATH /Users/intiartha/Documents/castercode/nutech/resources/views/master/produk/create.blade.php ENDPATH**/ ?>