<a href="<?php echo e($url_show); ?>" class="btn-floating btn-sm btn-secondary" title="Detail"><i class="fa fa-search"></i></a>
<a href="<?php echo e($url_edit); ?>" class="btn-floating btn-sm btn-primary" title="Edit"><i class="fa fa-edit"></i></a>
<a href="<?php echo e($url_destroy); ?>" class="btn-floating btn-sm btn-danger" title="Delete"><i class="fa fa-trash"></i></a>

<?php /**PATH D:\Rian\engineering_fee\resources\views/master/user/action.blade.php ENDPATH**/ ?>