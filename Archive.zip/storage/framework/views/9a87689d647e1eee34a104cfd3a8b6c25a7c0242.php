

<div class="modal fade" id="modal" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static" aria-labelledby="myModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg modal-notify modal-info" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <p class="heading lead" id="modal-title">Modal Info</p>

          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="white-text">&times;</span>
          </button>
        </div>

        <div class="modal-body" id="modal-body">
          
        </div>

        <div class="modal-footer">
          <a type="button" class="btn btn-danger" data-dismiss="modal">Cancel</a>
          <a type="button" class="btn btn-primary waves-effect"  id="modal-btn-save">Save</a>
        </div>
      </div>
      <!--/.Content-->
    </div>
  </div><?php /**PATH /Users/intiartha/Documents/castercode/engineering_fee/resources/views/base/modal.blade.php ENDPATH**/ ?>