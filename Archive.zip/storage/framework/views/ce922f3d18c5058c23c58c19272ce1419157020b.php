<?php
    $method = $model->exists ? 'PUT' : 'POST';
?>
<?php echo Form::model($model, [
    'route' => $model->exists ? ['project.project.update', $model->id] : 'project.project.store',
    'method'=> $method,
]); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="project_name" class="control-label">Project Name*</label>
                <?php echo Form::text('project_name', null, ['class'=>'form-control', 'id'=>'project_name']); ?>

            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <label for="project_name" class="control-label">Project Category*</label>
                <?php echo Form::select('project_category', $category, $categoryList, ['class'=>'form-control']); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="project_start" class="control-label">Start Project*</label>
                <?php echo Form::date('project_start', $start, ['class'=>'form-control', 'id'=>'project_start']); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="project_end" class="control-label">End Project*</label>
                <?php echo Form::date('project_end', $end, ['class'=>'form-control', 'id'=>'project_end']); ?>

            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <label for="project_description" class="control-label">Project Description*</label>
                <?php echo Form::textarea('project_description', null, ['class'=>'form-control', 'id'=>'project_description']); ?>

            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <label for="project_detail" class="control-label">Project Detail*</label>
                <?php echo Form::textarea('project_detail', null, ['class'=>'form-control', 'id'=>'project_detail']); ?>

            </div>
        </div>
    </div>

<?php echo Form::close(); ?>

<?php /**PATH /Users/intiartha/Documents/castercode/management_pro/resources/views/master/project/create.blade.php ENDPATH**/ ?>