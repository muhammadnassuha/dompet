<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.4.13
  </div>
  <strong>Copyright &copy; 2020 <a href="#">Management Project</a>.</strong> All rights reserved. 
</footer><?php /**PATH /Users/intiartha/Documents/castercode/nutech/resources/views/base/footer.blade.php ENDPATH**/ ?>