<header class="main-header">
  <a href="/" class="logo">
  <span class="logo-mini"><b>M</b>P</span>
  <span class="logo-lg"><b>Management</b>Project</span>
  </a>
  <nav class="navbar navbar-static-top">
  <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"><span class="sr-only">Toggle navigation</span></a>

  <div class="navbar-custom-menu">
    <ul class="nav navbar-nav">

      <li class="dropdown user user-menu">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <img src="<?php echo e(asset('images/img-user2-160x160.jpg')); ?>" class="user-image" alt="User Image"><span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span></a>
        <ul class="dropdown-menu">
          <!-- User image -->
          <li class="user-header">
            <img src="<?php echo e(asset('images/img-user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
            <p>
               <?php echo e(Auth::user()->name); ?> <small>Member since Nov. 2012</small>
            </p>
          </li>
          <li class="user-footer">
            <div class="pull-left">
              <a href="#" class="btn btn-default btn-flat">Profile</a>
            </div>
            <div class="pull-right">
              <a class="btn btn-default btn-flat" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">Log Out
              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
            </div>
          </li>
        </ul>
      </li>
      
    </ul>
  </div>
  </nav>
  </header><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/base/header.blade.php ENDPATH**/ ?>