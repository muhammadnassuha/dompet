<table class="table table-striped table-condensed">
	<tr>
		<th>Nama Role</th>
		<td><?php echo e($model->role); ?></td>
	</tr>
	<tr>
		<th>Code</th>
		<td><?php echo e($model->code); ?></td>
	</tr>
	<tr>
		<th>Active</th>
		<td><?php echo e($model->active == 1 ? 'Yes' : 'No'); ?></td>
	</tr>
	<tr>
		<th>Created By</th>
		<td><?php echo e($uti->getUser($model->created_by)); ?></td>
	</tr>
	<tr>
		<th>Created Date</th>
		<td><?php echo e(date('d-m-Y H:i:s', strtotime($model->created_at))); ?></td>
	</tr>
	<tr>
		<th>Updated By</th>
		<td><?php echo e($uti->getUser($model->updated_by)); ?></td>
	</tr>
	<tr>
		<th>Updated Date</th>
		<td><?php echo e(date('d-m-Y H:i:s', strtotime($model->updated_at))); ?></td>
	</tr>
</table><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/master/role/detail.blade.php ENDPATH**/ ?>