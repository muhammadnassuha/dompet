<!-- <footer class="page-footer pt-0 mt-5 rgba-stylish-light">
<div class="footer-copyright py-3 text-center">
  <div class="container-fluid">
     &copy; 2020 Copyright: <a href="#" target="_blank">Engineering Fee</a>
  </div>
</div>
</footer> --><?php /**PATH D:\Rian\engineering_fee\resources\views/base/footer.blade.php ENDPATH**/ ?>