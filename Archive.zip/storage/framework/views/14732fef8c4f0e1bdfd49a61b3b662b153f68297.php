
<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
  <li>
  	<a href="<?php echo e(route('produk.produk.index')); ?>"><i class="fa fa-cubes"></i> Produk </a>
  </li>
</ul><?php /**PATH /Users/intiartha/Documents/castercode/nutech/resources/views/base/menu.blade.php ENDPATH**/ ?>