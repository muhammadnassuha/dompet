<script src="<?php echo e(asset('js/dist-jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js-bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib-fastclick.js')); ?>"></script>
<script src="<?php echo e(asset('js/js-adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dist-jquery.sparkline.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jvectormap-jquery-jvectormap-1.2.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jvectormap-jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-slimscroll-jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/chart.js-Chart.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages-dashboard2.js')); ?>"></script>
<script src="<?php echo e(asset('js/js-demo.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('select2/dist/js/select2.full.min.js')); ?>"></script>
<script>
	$(function () {
	  $('.select2').select2()
	});

	$(document).ready(function(){
	  	var url = window.location.href;
	  	var attr = $('li').data('href');

	  	// alert(attr);

	});
</script> 


<?php echo $__env->yieldPushContent('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/base/script.blade.php ENDPATH**/ ?>