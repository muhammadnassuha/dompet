<?php $__env->startSection('title'); ?> Access Role <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_icon'); ?> <i class="fa fa-cog"></i> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?> Detail Access Role <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> list <?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <div class="box box-solid" style="text-align:right;">
        <div class="box-body">
            <a href="<?php echo e(route('accessrole.access-role.index')); ?>" class="btn btn-success" title="Manage Access Role">
                <i class="fa fa-list"></i> Manage
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="box box-solid">
	<div class="box-body">
		<div class="box-body">
			<h4>Role : <strong><?php echo e($role->role); ?></strong></h4>
			<table id="datatable" class="table table-hover table-condensed table-bordered">
	            <thead>
	            	<tr>
	            		<th width="50px">No</th>
	            		<th>Module</th>
	            		<th>Read</th>
	            		<th>Create</th>
	            		<th>Update</th>
	            		<th>Delete</th>
	            		<th>Show</th>
	            	</tr>
	            </thead>
	            <?php
	            	$no = 1;
	            	$action = ['R','C','U','D','S']; 
	            ?>
	            <tbody>
	            	<?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            	<tr>
		            		<td><?php echo e($no++); ?></td>
		            		<td><strong><?php echo e($module->module); ?></strong></td>
		            		<?php for($a = 0; $a < count($action); $a++): ?>
		            			<?php $checked = false; ?>
		            			<?php if($model->isActionChecked($module->id, $action[$a], $actions)): ?>
		            				<?php $checked = true; ?>
		            			<?php endif; ?>
		            			<td width="100px" style="text-align: center;">
		            				<?php if($model->isHasChild($module->id) > 0 && in_array($action[$a], ['R','C','U','D'])): ?>
		            					<?php continue; ?>
		            				<?php endif; ?>
		            				<input type="checkbox" class="checkbox_act" data-role="<?php echo e($role->id); ?>" data-module="<?php echo e($module->id); ?>" data-act="<?php echo e($action[$a]); ?>" <?php echo e($checked ? "checked" : ""); ?>>
		            			</td>	
		            		<?php endfor; ?>
		            	</tr>
	            		<?php if($module->parent_id == null): ?>
	            			<?php $__currentLoopData = $model->getModuleChild($module->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            			<tr>
	            				<td><?php echo e($no++); ?></td>
			            		<td style="padding-left: 30px;"><?php echo e($child->module); ?></td>

			            		<?php for($b = 0; $b < count($action); $b++): ?>
			            			<?php $checked = false; ?>
			            			<?php if($model->isActionChecked($child->id, $action[$b], $actions)): ?>
			            				<?php $checked = true; ?>
			            			<?php endif; ?>
			            			<td width="100px" style="text-align: center;">
			            				<?php if($model->isHasChild($child->id) > 0 && in_array($action[$b], ['R','C','U','D'])): ?>
			            					<?php continue; ?>
			            				<?php endif; ?>
				            			<input type="checkbox" class="checkbox_act" data-role="<?php echo e($role->id); ?>" data-module="<?php echo e($child->id); ?>" data-act="<?php echo e($action[$b]); ?>" <?php echo e($checked ? "checked" : ""); ?>>
				            		</td>
			            		<?php endfor; ?>	
	            			</tr>
	            			<?php
	            				$child_second = $model->getModuleChild($child->id);
	            			?>
	            			<?php if($child_second != null): ?>
	            				<?php $__currentLoopData = $child_second; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            			<tr>
		            				<td><?php echo e($no++); ?></td>
				            		<td style="padding-left: 60px;"><?php echo e($child2->module); ?></td>

				            		<?php for($c = 0; $c < count($action); $c++): ?>
				            			<?php $checked = false; ?>
				            			<?php if($model->isActionChecked($child2->id, $action[$c], $actions)): ?>
				            				<?php $checked = true; ?>
				            			<?php endif; ?>
				            			<td width="100px" style="text-align: center;">
					            			<input type="checkbox" class="checkbox_act" data-role="<?php echo e($role->id); ?>" data-module="<?php echo e($child2->id); ?>" data-act="<?php echo e($action[$c]); ?>" <?php echo e($checked ? "checked" : ""); ?>>
					            		</td>
				            		<?php endfor; ?>
		            			</tr>
	            				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            			<?php endif; ?>
	            			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            		<?php endif; ?>
	            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            </tbody>
	        </table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

	$('.checkbox_act').on('click', function(){
		var role = $(this).data('role'),
			module = $(this).data('module'),
			act = $(this).data('act'),
			token = $('meta[name="csrf-token"]').attr('content');

		var action = '';
		if(act == 'R')
			action = 'Read';
		else if(act == 'C')
			action = 'Create';
		else if(act == 'U')
			action = 'Update';
		else if(act == 'D')
			action = 'Delete';
		else if(act == 'S')
			action = 'Show';
		else
			action = 'Unknown';

		if($(this).is(":checked")) 
		{
			// alert('checked '+role+'-'+module+'-'+act);
			$.ajax({
				url : "<?php echo e(route('accessrole.access-role.add-act')); ?>",
				method : 'post',
				data : {
					role : role,
					module : module,
					action : act,
					_token : token
				},
				success : function(result){
					swal({
                        type : 'success',
                        title : 'Success',
                        text : 'Module : '+module+', Action : '+action+', Added'
                    });
				},
				error : function(er){
                    swal({
                        type : 'error',
                        title : 'Failed',
                        text : 'Failed'
                    });
                }
			});
		}
		else
		{
			// alert('unchecked '+role+'-'+module+'-'+act);
			$.ajax({
				url : '<?php echo e(route("accessrole.access-role.remove-act")); ?>',
				method : 'post',
				data : {
					role : role,
					module : module,
					action : act,
					_token : token
				},
				success : function(r){
					swal({
                        type : 'success',
                        title : 'Deleted',
                        text : 'Module : '+module+', Action : '+action+', Deleted'
                    });
				},
				error : function(er){
                    swal({
                        type : 'error',
                        title : 'Failed',
                        text : 'Failed'
                    });
                }
			});
		}
	});

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('base.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/setting/access-role/detail.blade.php ENDPATH**/ ?>