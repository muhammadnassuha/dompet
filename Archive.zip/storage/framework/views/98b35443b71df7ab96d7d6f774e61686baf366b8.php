<?php $__env->startSection('title'); ?> Access Role <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_icon'); ?> <i class="fa fa-cog"></i> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?> Access Role <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> list <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-solid">
        <div class="box-body">
            <table id="datatable" class="table table-hover table-condensed table-bordered">
                <thead>
                    <tr>
                        <th width="50px">No</th>
                        <th>Role</th>
                        <th width="100px">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#datatable').DataTable({
            responsive : true,
            processing : true,
            serverSide : true,
            ajax: "<?php echo e(route('table.access-role')); ?>",
            columns: [
                {data : 'DT_RowIndex', name : 'id'},
                {data : 'role', name : 'role'},
                {data : 'action', name : 'action'}
            ]
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('base.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/setting/access-role/index.blade.php ENDPATH**/ ?>