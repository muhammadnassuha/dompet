<nav class="navbar fixed-top navbar-expand-lg scrolling-navbar double-nav">
<!-- SideNav slide-out button -->
<div class="float-left">
  <a href="#" data-activates="slide-out" class="button-collapse"><i class="fas fa-bars"></i></a>
</div>
<!-- Breadcrumb -->
<div class="breadcrumb-dn mr-auto">
  <p>
    E-Fee
  </p>
</div>
<div class="d-flex change-mode">
  <div class="ml-auto mb-0 mr-3 change-mode-wrapper">
    <!-- <button class="btn btn-outline-black btn-sm" id="dark-mode">Change Mode</button> -->
  </div>
  <!-- Navbar links -->
  <ul class="nav navbar-nav nav-flex-icons ml-auto">
    <!-- Dropdown -->
    
    <li class="nav-item">
      <a class="nav-link waves-effect" href="dashboards.html"><i class="fas fa-envelope"></i><span class="clearfix d-none d-sm-inline-block">Contact</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link waves-effect" href="dashboards.html"><i class="far fa-comments"></i><span class="clearfix d-none d-sm-inline-block">Support</span></a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle waves-effect" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user"></i><span class="clearfix d-none d-sm-inline-block">Profile</span></a>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Log Out
        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
        </form>
        <a class="dropdown-item" href="#">My account</a>
      </div>
    </li>
  </ul>
  <!-- Navbar links -->
</div>
</nav><?php /**PATH /Users/intiartha/Documents/castercode/management_pro/resources/views/base/navbar.blade.php ENDPATH**/ ?>