<?php
    $method = $model->exists ? 'PUT' : 'POST';
?>
<?php echo Form::model($model, [
    'route' => $model->exists ? ['role.role.update', $model->id] : 'role.role.store',
    'method'=> $method,
]); ?>


    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="code" class="control-label">Code</label>
                <?php echo Form::text('code', null, ['class'=>'form-control', 'id'=>'code', 'maxlength'=>5]); ?>

            </div>
        </div>

        <div class="col-md-8">
            <div class="form-group">
                <label for="role" class="control-label">Role</label>
                <?php echo Form::text('role', null, ['class'=>'form-control', 'id'=>'role']); ?>

            </div>
        </div>
    </div>

<?php echo Form::close(); ?><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/master/role/create.blade.php ENDPATH**/ ?>