<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Dashboard Engineering Fee</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
<link rel="stylesheet" href="<?php echo e(asset('css/css-bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/css-mdb.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/addons-datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/addons-datatables-select.min.css')); ?>">
<style></style>
</head><?php /**PATH D:\Rian\engineering_fee\resources\views/base/head.blade.php ENDPATH**/ ?>