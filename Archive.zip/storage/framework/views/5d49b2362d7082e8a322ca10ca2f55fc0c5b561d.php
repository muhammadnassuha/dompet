<?php
    $method = $model->exists ? 'PUT' : 'POST';
?>
<?php echo Form::model($model, [
    'route' => $model->exists ? ['menu.menu.update', $model->id] : 'menu.menu.store',
    'method'=> $method,
]); ?>


    <div class="form-group">
        <label for="name" class="control-label">Name</label>
        <?php echo Form::text('module', null, ['class'=>'form-control', 'id'=>'module']); ?>

    </div>
	 <div class="form-group">
        <label for="link" class="control-label">Link</label>
        <?php echo Form::text('link', null, ['class'=>'form-control', 'id'=>'link']); ?>

    </div>
	 <div class="form-group">
        <label for="icon" class="control-label">Icon</label>
        <?php echo Form::text('icon', null, ['class'=>'form-control', 'id'=>'icon']); ?>

    </div>
	 <div class="form-group">
        <label for="sort" class="control-label">Sort</label>
        <?php echo Form::text('sort', null, ['class'=>'form-control', 'id'=>'sort']); ?>

    </div>
<div class="form-group">
        <label for="page_id" class="control-label">Parent Name</label>
        <?php echo Form::select('parent_id', [''=>'- Select -']+$page, null, ['class'=>'form-control', 'id'=>'parent_id']); ?>

    </div>
	<div class="form-group">
		<label for="active" class="control-label">Active</label>
		<div>
			<?php echo Form::checkbox('active', null, null, ['id'=>'active']); ?> 
		</div>
		<?php if($errors->has('active')): ?>
			<span class="invalid-feedback" role="alert">
				<?php echo e($errors->first('active')); ?>

			</span>
		<?php endif; ?>
	</div>

    

<?php echo Form::close(); ?><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/setting/menu/create.blade.php ENDPATH**/ ?>