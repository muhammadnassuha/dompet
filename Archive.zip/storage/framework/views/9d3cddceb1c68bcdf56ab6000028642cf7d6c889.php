<?php
  use App\Utility;

  $uti = new Utility;
?>
<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
  <?php $uti->listMenu(); ?>  

</ul><?php /**PATH /Users/intiartha/Documents/castercode/base_laravel/resources/views/base/menu.blade.php ENDPATH**/ ?>