<?php
  use Illuminate\Support\Facades\Auth;
?>
<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
  <li>
    <a href="<?php echo e(route('home')); ?>">
      <i class="fa fa-dashboard"></i> 
      <span>Dashboard</span>
    </a>
  </li>
  <li class="treeview">
    <a href="#">
      <i class="fa fa-laptop"></i>
      <span>Management Project</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li>
        <a href="<?php echo e(route('project.project.index')); ?>"><i class="fa fa-circle-o"></i>Data Project</a>
      </li>
      <li>
        <a href="<?php echo e(route('category.category-project.index')); ?>"><i class="fa fa-circle-o"></i>Category Project</a>
      </li>
    </ul>
  </li>
  

  <?php if(Auth::user()->role == "administrator"): ?>
  <li class="header">SETTING</li>
  <li>
    <a href="<?php echo e(route('user.sys-user.index')); ?>">
      <i class="fa fa-users"></i> 
      <span>Management User</span>
    </a>
  </li>
  <?php else: ?>

  <?php endif; ?>
</ul><?php /**PATH /Users/intiartha/Documents/castercode/management_pro/resources/views/base/menu.blade.php ENDPATH**/ ?>