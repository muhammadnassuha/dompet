<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('base.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="fixed-sn white-skin">
<header>
<!-- Menu navigation -->
<?php echo $__env->make('base.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Menu navigation -->
<!-- Navbar -->
<?php echo $__env->make('base.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Navbar -->
</header>

<!-- Main layout -->
<main>
<div class="container-fluid">
  <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('base.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

</main>
<!-- Main layout -->
<?php echo $__env->make('base.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('base.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\Rian\engineering_fee\resources\views/base/main.blade.php ENDPATH**/ ?>