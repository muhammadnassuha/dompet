
<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
  <li>
  	<a href="{{ route('produk.produk.index') }}"><i class="fa fa-cubes"></i> Produk </a>
  </li>
</ul>