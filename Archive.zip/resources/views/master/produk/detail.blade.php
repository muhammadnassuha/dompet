
<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered">
			<tbody>
				@if($model->foto_barang == "")
				<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/No_image_3x4.svg/1280px-No_image_3x4.svg.png" style="width: 600px; height: 300px;" class="img-thumbnail" alt="Cinque Terre">
				@else
				<img src="{{ asset($model->foto_barang) }}" style="width: 600px; height: 300px;" class="img-thumbnail" alt="Cinque Terre">
				@endif
				<br>
				<br>
				
				<tr>
					<th>Nama Barang</th>
					<td>{{ $model->nama_barang }}</td>
				</tr>
				<tr>
					<th>Harga Jual</th>
					<td>Rp. {{ number_format($model->harga_jual) }}</td>
				</tr>
				<tr>
					<th>Harga Beli</th>
					<td>Rp. {{ number_format($model->harga_beli) }}</td>
				</tr>
				<tr>
					<th>Stok</th>
					<td>{{ $model->stok }}</td>
				</tr>
                <tr>
                    <th>Created Date</th>
                    <td>{{ date('d-m-Y H:i', strtotime($model->created_at)) }} WIB</td>
                </tr>
                <tr>
                    <th>Updated Date</th>
                    <td>{{ date('d-m-Y H:i', strtotime($model->updated_at)) }} WIB</td>
                </tr>
			</tbody>
		</table>
	</div>
	
</div>
