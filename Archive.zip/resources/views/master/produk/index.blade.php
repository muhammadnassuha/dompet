@extends('base.main')
@section('page_icon') <i class="fa fa-dashboard"> </i>@endsection
@section('page_title') Dashboard @endsection
@section('page_subtitle') Produk @endsection
@section('menu')
    <div class="bg-aqua">
    <div class="box-header with-border" style="height: 50px;">
        <h3 class="box-title" style="color: white; margin-top: 5px;">Produk List</h3>

        <div class="box-tools pull-right">
            <a class="modal-show btn btn-primary" style="margin-top: 3px;" href="{{ route('produk.produk.create') }}" title="Create Produk">Create</a></li>
        </div>
    </div>
</div>
@endsection

@section('content')
    <div class="box box-solid">
        
        <div class="box-body">
            <table id="datatable" class="table table-hover table-condensed">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Nama Barang</th>
                        <th width="15%">Harga Barang</th>
                        <th width="10%">Stok</th>
                        <th width="10%">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@push('scripts')
    <script>

        $('#datatable').DataTable({
            responsive : true,
            processing : true,
            serverSide : true,
            ajax: "{{ route('table.produk') }}",
            columns: [
                {data : 'DT_RowIndex', name : 'id'},
                {data : 'nama_barang', name : 'nama_barang'},
                {data : 'harga_jual', name : 'harga_jual'},
                {data : 'stok', name : 'stok'},
                {data : 'action', name : 'action'}
            ]
        });
    </script>
@endpush

