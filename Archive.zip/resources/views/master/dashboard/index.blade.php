@extends('base.main')
@section('page_icon') <i class="fa fa-dashboard"> </i>@endsection
@section('page_title') Dashboard @endsection
@section('page_subtitle') Home @endsection

@section('content')
<div class="callout callout-info" style="margin-bottom: 0!important;">
    <h4><i class="fa fa-info"></i> Welcome </h4>
    Perkenalkan nama saya Rian, berikut page <a href="">Produk </a> dari soal Test Praktek PHP Programmer yang telah saya buat <br>dengan sebaik mungkin yang mencakup beberapa point utama dan point tambahan. Selamat mencoba :) 
</div>
@endsection