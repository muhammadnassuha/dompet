<?php

use Illuminate\Support\Facades\Route;
// All Routes

Auth::routes();
Route::get('/', 'HomeController@index')->name('home'); 

Route::resource('produk', 'MProdukController', ['as' => 'produk']);
Route::get('table/produk', 'MProdukController@dataTable')->name('table.produk');
Route::post('produk/image', 'MProdukController@imageUpload')->name('produk.image');
Route::post('produk/show-image', 'MProdukController@showImage')->name('produk.show-image');